package com.example.flight.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.flight.service.FlightService;

@RestController
@RequestMapping("/api/flights")
public class FlightController {
	
	private FlightService flightService;
	
	public FlightController(FlightService flightService)
	{
		this.flightService = flightService;
	}
	
	@GetMapping("/{flightNumber}")
	public String getFlight(@PathVariable String flightNumber) {
		
		return flightService.getFlight(flightNumber);
	}
}
