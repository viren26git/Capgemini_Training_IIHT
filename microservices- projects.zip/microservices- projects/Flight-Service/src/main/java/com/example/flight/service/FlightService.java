package com.example.flight.service;

import org.springframework.stereotype.Service;

@Service
public class FlightService {
	
	public String getFlight(String flightNumber) {
		
		return "Flight " + flightNumber + " is available";
	}
}
