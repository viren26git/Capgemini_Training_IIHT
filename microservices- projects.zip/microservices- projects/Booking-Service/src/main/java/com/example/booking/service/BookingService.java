package com.example.booking.service;

import org.springframework.stereotype.Service;
import com.example.booking.client.FlightClient;
import io.github.resilience4j.bulkhead.annotation.Bulkhead;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@Service
public class BookingService {

    private final FlightClient flightClient;

    public BookingService(FlightClient flightClient) {
        this.flightClient = flightClient;
    }

    @Retry(name = "flightService")
    @CircuitBreaker(name = "flightService",fallbackMethod = "flightFallBack")
    @Bulkhead(name = "flightService",type = Bulkhead.Type.SEMAPHORE)
    public String bookFlight(String flightNumber) {

       String flightDetails = flightClient.getFlight(flightNumber);
       return "Booking confirmed: " + flightDetails;
    }

    public String flightFallBack(String flightNumber,Throwable ex) {
        System.out.println("FALLBACK METHOD EXECUTED");
        return "Flight service is currently unavailable for " + flightNumber + ". Please try again later.";
    }
}