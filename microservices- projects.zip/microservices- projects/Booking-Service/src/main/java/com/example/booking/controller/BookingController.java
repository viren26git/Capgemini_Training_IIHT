package com.example.booking.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.booking.service.BookingService;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {
	
	private BookingService bs;
	
	public BookingController(BookingService bs) {
		this.bs=bs;
	}
	
	@GetMapping("/booking/{flightNumber}")
	public String bookFlight(@PathVariable String flightNumber) {
		return bs.bookFlight(flightNumber);
	}

}
