package com.example.product.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;
import com.example.product.ProductCrudApplication;
import com.example.product.controller.ProductController;
import com.example.product.model.Product;

@Service
public class ProductService {
	
	private List<Product> products = new ArrayList<>();
	
	private Long nextId = 1L;
	
	// adding
	public Product addProduct(Product prod) {
		prod.setId(nextId++); 
		products.add(prod);
		System.out.println(products);
		
		return prod;
	}
	
	// fetch all
	public List<Product> getAllProducts(){
		return products;
	}
	
	//fetch signle product
	public Product getProductById(Long id) {
		
		for(Product p :products) {
			if(p.getId().equals(id)) {
				return p;
			}
		}
		
		throw new RuntimeException("Product not found");
	}
	
	   // updating
	public Product updateProduct(Long id, Product prod) {
		
		    Product existingroduct = getProductById(id);
		    
		    existingroduct.setName(prod.getName()); 
		    existingroduct.setPrice(prod.getPrice()); 
		    existingroduct.setQuantity(prod.getQuantity());
			
			return existingroduct;
		}
	
	//deleting
	public void deleteProduct(Long id) {
		
		Product existingroduct = getProductById(id);
		products.remove(existingroduct);
		
	}

}
