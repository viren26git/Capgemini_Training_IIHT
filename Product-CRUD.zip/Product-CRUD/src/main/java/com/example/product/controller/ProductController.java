package com.example.product.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.product.model.Product;
import com.example.product.service.ProductService;

@Controller
@RequestMapping("/api/products")
public class ProductController {
	
	private ProductService service;
	
	public ProductController(ProductService service) {  // constructor DI
		this.service= service;
	}
	
	//CREATE
	@RequestMapping(value = "/addProduct",method = RequestMethod.POST)
	public ResponseEntity<Product> addProduct(@RequestBody Product product) {
		
		Product savedProduct = service.addProduct(product);
		return new ResponseEntity<>(savedProduct, HttpStatus.CREATED);
	}
	
	//fetchall
	@RequestMapping(value = "/getAllProducts",method = RequestMethod.GET)
	public ResponseEntity<List<Product>> getAllProducts(){
		return ResponseEntity.ok(service.getAllProducts());
	}
	
	//fetch signle product
	@RequestMapping(value = "/getSingleProduct/{id}",method = RequestMethod.GET)
	public ResponseEntity<Product> getProductById(@PathVariable Long id) {
		return ResponseEntity.ok(service.getProductById(id));
	}
	
	//updating
	@RequestMapping(value = "/updateProduct/{id}",method = RequestMethod.PUT)
	public ResponseEntity<Product> updateProduct(@PathVariable Long id, @RequestBody Product prod) {
		return ResponseEntity.ok(service.updateProduct(id, prod));
	}
	
	//deleting
	@RequestMapping(value = "/deleteProduct/{id}",method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteProduct(@PathVariable Long id)
	{
		service.deleteProduct(id);
		return ResponseEntity.ok("Product is deleted successfully");
	}
}
