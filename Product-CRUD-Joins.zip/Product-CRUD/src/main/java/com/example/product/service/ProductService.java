package com.example.product.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import com.example.product.ProductCrudApplication;
import com.example.product.controller.ProductController;
import com.example.product.model.Category;
import com.example.product.model.Product;
import com.example.product.repository.CategoryRepository;
import com.example.product.repository.ProductRepository;

@Service
public class ProductService {
	
	private ProductRepository pr;
	private CategoryRepository cr;
	
	public ProductService(ProductRepository pr, CategoryRepository cr) {
		this.pr=pr;
		this.cr=cr;
	}
	
	// adding with category id validation
	public Product addProduct(Product prod) throws Exception { 
		
		if(prod.getCategory() != null) {
			Long categoryId = prod.getCategory().getId();
			
			Category category = cr.findById(categoryId).orElseThrow( () -> new Exception("Category Not found with id:" + categoryId));
		    prod.setCategory(category);
		}
		
		return pr.save(prod);   
	}
	
	// fetch all
	public List<Product> getAllProducts(){
		return pr.findAll(); 
	}
	
	//fetch signle product
	public Product getProductById(Long id) throws Exception {
		  return pr.findById(id).orElseThrow(() -> new Exception("Product id not found")); 
	}
	
	   // updating with category id validation
	public Product updateProduct(Long id, Product prod) throws Exception { 
		
		    Product existingroduct = pr.findById(id).orElseThrow(() -> new Exception("Product id not found"));
		    
		    existingroduct.setName(prod.getName()); 
		    existingroduct.setPrice(prod.getPrice()); 
		    existingroduct.setQuantity(prod.getQuantity());
		    
		    if(prod.getCategory() != null) {
				Long categoryId = prod.getCategory().getId();
				
				Category category = cr.findById(categoryId).orElseThrow( () -> new Exception("Category Not found with id:" + categoryId));
				existingroduct.setCategory(category);
			}
			
			return pr.save(existingroduct);
		}
	
	//deleting
	public void deleteProduct(Long id) throws Exception { 
		
		Product existingroduct1 = pr.findById(id).orElseThrow(() -> new Exception("Product id not found"));
		pr.delete(existingroduct1); 
		
	}
}
