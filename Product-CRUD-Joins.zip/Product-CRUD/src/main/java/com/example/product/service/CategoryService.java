package com.example.product.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.product.model.Category;
import com.example.product.repository.CategoryRepository;

@Service
public class CategoryService {
	
	private CategoryRepository cr;
	
	public CategoryService(CategoryRepository cr)
	{
		this.cr=cr;
	}
	
	public Category addCategory(Category category) {
		return cr.save(category);
	}
	
	public List<Category> getAllCategories(){
		return cr.findAll();
	}
	
	public Category getCategoryById(Long id) throws Exception {
		return cr.findById(id).orElseThrow(() -> new Exception("Catgegory not found"));  
	}
	
	public void deleteCategory(Long id) throws Exception {
		Category category = getCategoryById(id); 
		cr.delete(category); 
		
	}

}
