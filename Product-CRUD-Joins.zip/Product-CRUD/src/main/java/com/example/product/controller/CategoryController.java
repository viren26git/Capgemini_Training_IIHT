package com.example.product.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.product.model.Category;
import com.example.product.service.CategoryService;

@RestController
@RequestMapping("/api/categories")
public class CategoryController {
	
	private CategoryService cs;
	
	public CategoryController(CategoryService cs) {
		this.cs=cs;
	}
	
	@PostMapping("/add")
	public ResponseEntity<Category> addCategory(@RequestBody Category category){
		Category savedCategory = cs.addCategory(category);
		
		return new ResponseEntity<>(savedCategory,HttpStatus.CREATED);
	}
	
	@GetMapping("/allCategories")
	public ResponseEntity<List<Category>> getAllCategories(){
		return ResponseEntity.ok(cs.getAllCategories());
	}
	
	@GetMapping("/category/{id}")
	public ResponseEntity<Category> getCategoryById(@PathVariable Long id) throws Exception{ 
		return ResponseEntity.ok(cs.getCategoryById(id));
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteCategory(@PathVariable Long id) throws Exception{ 
		cs.deleteCategory(id);
		return ResponseEntity.ok("Category deleted successfully");
	}

}
