package com.example.kafka.controller;

import org.apache.kafka.common.Uuid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.kafka.producer.BookingProducer;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {
	
	private BookingProducer bookingProducer;
	
	public BookingController(BookingProducer bookingProducer) {
		this.bookingProducer = bookingProducer;
	}

	@GetMapping("/create")
	public String createBooking() {
		
		String eventId = Uuid.randomUuid().toString();
		
		String message = eventId + "|B101" + "|AI101" + "|BOOKING_CREATED";
		bookingProducer.sendBookingEvent(eventId, message);
		
		return "Booking event is sent succesfully!!";
	}
}
