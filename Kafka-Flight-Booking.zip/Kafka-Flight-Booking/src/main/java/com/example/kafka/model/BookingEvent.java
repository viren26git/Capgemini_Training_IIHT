package com.example.kafka.model;

public class BookingEvent {
	
	private String eventId;
	private String bookingId;
	private String flightNumber;
	private String status;
	
	public BookingEvent() {}
	
	public BookingEvent(String eventId,String bookingId,String flightNumber,String status) {
		this.eventId=eventId;
		this.bookingId= bookingId;
		this.flightNumber= flightNumber;
		this.status=status;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
}
