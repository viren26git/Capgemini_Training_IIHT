package com.example.kafka.consumer;

import java.util.HashSet;
import java.util.Set;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class BookingConsumer {
	
	private Set<String> processedEvents = new HashSet<>();
	
    @KafkaListener(topics="booking-events",groupId="booking-group")
	public void consume(String message) {
		
    	String eventId = message.split("\\|")[0];
    	
    	System.out.println("Received event " + message);
    	
    	if(processedEvents.contains(eventId)) {
    		System.out.println("Duplicate event we can ignore " + eventId);
    		return;
    	}
    	
    	processedEvents.add(eventId);
    	
    	System.out.println("Processing booking event " + eventId);
    	System.out.println("Booking processed successfully !!! ");
	}
}
