package com.example.kafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaFlightBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaFlightBookingApplication.class, args);
	}

}
