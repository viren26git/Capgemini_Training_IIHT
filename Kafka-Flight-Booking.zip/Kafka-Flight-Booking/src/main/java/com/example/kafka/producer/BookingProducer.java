package com.example.kafka.producer;

import org.springframework.stereotype.Service;
import org.springframework.kafka.core.KafkaTemplate;

@Service
public class BookingProducer {
	
	private KafkaTemplate<String,String> kafkaTemplate;
	
    public BookingProducer(KafkaTemplate<String,String> kafkaTemplate) {
    	this.kafkaTemplate = kafkaTemplate;
    }
    
    public void sendBookingEvent(String eventId, String message) {
    	kafkaTemplate.send("booking-events",eventId,message);
    	System.out.println("Event sent to kafka " + message);
    }
    
}
