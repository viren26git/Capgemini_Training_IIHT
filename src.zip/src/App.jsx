import NavBar from "./components/NavBar"
import NotFound from "./pages/NotFound"
import ProductDetails from "./pages/ProductDetails"
import Products from "./pages/Products"
import Home from "./pages/Home"
import Cart from "./pages/Cart"
import {Routes,Route} from "react-router-dom"

function App(){
  return(
    <div>
      <NavBar />

      <div>
        <Routes>
           <Route path="/" element={<Home />} />
           <Route path="/products" element={<Products />} />
           <Route path="/cart" element={<Cart />} />
           <Route path="/products/:id"  element={<ProductDetails />}/>
          <Route path="*" element={<NotFound />} />
        </Routes>
      </div>
    </div>
  )
}

export default App;