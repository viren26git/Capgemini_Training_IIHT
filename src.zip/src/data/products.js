const products = [
  {
    id: 1,
    name: "Laptop",
    price: 65000,
    category: "Electronics",
    description: "High performance laptop for development and office work."
  },
  {
    id: 2,
    name: "Mobile Phone",
    price: 35000,
    category: "Electronics",
    description: "Latest smartphone with excellent camera quality."
  },
  {
    id: 3,
    name: "Headphones",
    price: 5000,
    category: "Accessories",
    description: "Wireless headphones with noise cancellation."
  }
];

export default products;