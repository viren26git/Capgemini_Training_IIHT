import {Link} from "react-router-dom"; 

//This will be viewed on the screen by the User
function NavBar(){
    return(
        <nav>
            <h2> My Store </h2>
            <div>
                <Link to="/"> Home  </Link>
                <Link to="/products"> Products  </Link>
                <Link to="/cart"> Cart  </Link>
            </div>
        </nav>
    )
}

export default NavBar;