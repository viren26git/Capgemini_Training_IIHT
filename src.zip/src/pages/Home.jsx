function Home(){
    return(
        <div>
            <h1> Welcome to My Product Store</h1>

            <p>
                Browse our products and also view their detailed in information
            </p>
        </div>
    )
}

export default Home