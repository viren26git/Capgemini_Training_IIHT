import { Link } from "react-router-dom"
import products from "../data/products"

function Products(){
    return(
        <div>
            <h1> All Products are Below:</h1>

           {
            products.map((product) =>(
                <div key={product.id} >
                   <h2> {product.name} </h2>
                   <p> Price : INR. {product.price} </p>
                   <Link to={`/products/${product.id}`}> 
                      View Details
                   </Link>
                   <hr/>
                </div>
            ))
           }
        </div>
    )
}

export default Products;