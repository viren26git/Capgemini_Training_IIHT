function NotFound(){
    return(
        <div>
            <h2> 404- Page Not Found</h2>

            <p> The page you are looking doesnot exist</p>
        </div>
    )
}

export default NotFound;