function Cart(){
    return(
        <div>
            <h2> Shopping cart</h2>
            <p> Your cart is current empty</p>
        </div>
    )
}

export default Cart