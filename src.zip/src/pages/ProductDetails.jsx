import products from "../data/products"
import { useParams } from "react-router-dom"

function ProductDetails(){
    const {id} = useParams();

    const product = products.find( (product) => product.id === Number(id))

    if(!product){
        return <h2> Product not found !!</h2>
    }

    return(
        <div>
            <h2> {product.name} </h2>
            <p> Price : INR. {product.price} </p>
            <p> Category : {product.category} </p>
            <p> Description :{product.description} </p>
        </div>
    )
}

export default ProductDetails