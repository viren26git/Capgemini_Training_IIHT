import { useState } from "react";
import ProductForm from "./components/ProductForm";
import ProductList from "./components/ProductList";

function App(){
   const[selectedProduct, setSelectedProduct] = useState(null)
   const [refresh, setRefresh] = useState(false) 

   const handleSuccess = () =>{
    setSelectedProduct(null)
    setRefresh(!refresh)
   }

   const handleEdit = (product) =>{
    console.log("Editing product:", product);
    setSelectedProduct(product)
   }

   return(
    <div>
      <h2> Product Management System </h2>
      
      <ProductForm product={selectedProduct} onSuccess={handleSuccess} />
      <hr/>
      <ProductList onEdit={handleEdit} key={refresh} />

    </div>
   )
}

export default App;