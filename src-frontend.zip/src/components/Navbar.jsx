function NavBar(){
    return(
        <div>
            <h2> E commerce Portal </h2>

            <div>
                <a href="http://localhost:5173"> Products </a>
                <a href="http://localhost:5174"> Order </a>
            </div>
        </div>
    )
}

export default NavBar;