import { useState } from "react";
import { createProduct, updateProduct } from "../service/productservice";

function ProductForm({product, onSuccess}){

    const [formData,setFormData] = useState({
        name: product?.name || "",
        description : product?.description || "",
        price : product?.price || "",
        quantity : product?.quantity || ""
    });

    const handleChange = (event) =>{
        setFormData({ 
            ...formData, [event.target.name]: event.target.value
        });
    }

    const handleSubmit = async(event) =>{
        event.preventDefault();

        try{
            if(product){
                await updateProduct(product.id,formData)
            }
            else{
                await createProduct(formData)
            }
            onSuccess()
        }
        catch(error){
            console.log("Error saving the product", error)
        }
    }

    return(
        <div>
            <h2> 
                {product ? "Update Product" : "Add Product"}
            </h2>

        <form onSubmit={handleSubmit}>
            <div>
               <label> Product Name</label>
               <input type="text" name="name" value={formData.name} onChange={handleChange} />  
             
               <br></br>
               <label> Product Description</label>
               <input type="text" name="description" value={formData.description} onChange={handleChange} /> 
               <br></br>

               <label> Product Price</label>
               <input type="text" name="price" value={formData.price} onChange={handleChange} /> 
               <br></br>

               <label> Product Quantity</label>
               <input type="text" name="quantity" value={formData.quantity} onChange={handleChange} /> 
               <br></br>

               <button type="submit" > {product ? "Update": "Save"} </button>
            </div>
        </form>
        </div>
      
    )
}

export default ProductForm;