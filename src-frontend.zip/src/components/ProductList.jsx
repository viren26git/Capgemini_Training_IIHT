
import { useState, useEffect } from 'react';
import { getProducts,deleteProduct } from '../service/productservice';

function ProductList({onEdit}){

    const [products,setProducts] = useState([]); 

    const loadProducts = async () =>{
        try{
            const response = await getProducts();
            console.log(response.data)
            setProducts(response.data);
        }
        catch(error){
            console.error("Error fetching products:", error);
        }
    }

    useEffect(() => {
        loadProducts();
    }, []); 

    const handleDelete = async(id) =>{
        try{
           await deleteProduct(id)
           loadProducts()
        }
        catch(error){
            console.log('error in deleting the product' + error)
        }
    }

    return(
        <div>
             <h2> Product List Below: </h2>
             <table border="2">
                <thead>
                    <tr>
                    <th> ID </th>
                    <th> Name </th>
                    <th> Description </th>
                    <th> Price </th>
                    <th> Quantity </th>
                    <th> Actions </th>
                    </tr>
                </thead>

                <tbody>
                    {products.map((product) => (
                        <tr key={product.id}>
                            <td>{product.id}</td>
                            <td>{product.name}</td>
                            <td>{product.description}</td>
                            <td>{product.price}</td>
                            <td>{product.quantity}</td>
                            <td>
                                <button onClick={()=> onEdit(product)}> Edit </button>
                                <button onClick={()=> handleDelete(product.id)}> Delete </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
             </table>
        </div>
    )
}

export default ProductList