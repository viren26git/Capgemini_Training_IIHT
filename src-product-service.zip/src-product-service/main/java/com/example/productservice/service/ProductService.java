package com.example.productservice.service;

import com.example.productservice.dto.ProductDTO;
import com.example.productservice.model.Product;

import java.util.List;

public interface ProductService {

    Product createProduct(ProductDTO productDTO);

    List<Product> getAllProducts();

    Product getProductById(Long id) ;

    Product updateProduct(Long id, ProductDTO productDTO);

    void deleteProduct(Long id) ;
}