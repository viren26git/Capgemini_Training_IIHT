import NavBar from "./components/NavBar";
import Cart from "./components/Cart";
import Products from "./components/Products";

function App(){
  return(
    <div>

      <NavBar /> 
      <Products />
      <Cart />

    </div>
  )
}

export default App;