import { useDispatch } from "react-redux";
import { addToCart } from "../features/cart/cartSlice";

function Products(){

    const dispatch = useDispatch();

    const products = [
  {
    id: 1,
    name: "Laptop",
    price: 65000,
  },
  {
    id: 2,
    name: "Mobile Phone",
    price: 35000,
  },
  {
    id: 3,
    name: "Headphones",
    price: 5000,
  }
];

return(
    <div>
    <h1> Products </h1>
    {
            products.map((product) =>(
                <div key={product.id} >
                   <h2> {product.name} </h2>
                   <p> Price : INR. {product.price} </p>
                   <button onClick={()=> dispatch(addToCart(product))}> Add To cart</button>
                   <hr/>
                </div>
            ))
    }
    </div>
   )
}

export default Products;