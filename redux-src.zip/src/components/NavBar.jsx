import { useSelector } from "react-redux";

function NavBar(){

    const cartItems = useSelector( state => state.cart.items )

    return(
        <nav>
            <h2> My store </h2>
            <h3> Cart : {cartItems.length}</h3>
        </nav>
    )
}

export default NavBar;