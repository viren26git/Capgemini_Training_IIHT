import { useSelector,useDispatch } from "react-redux";
import { clearCart, removeFromCart } from "../features/cart/cartSlice";


function Cart(){

    const cartItems = useSelector(state => state.cart.items)
    const dispatch = useDispatch();

    return(
        <div>
              <h2> Shopping cart </h2>
              <h3> Items : {cartItems.length} </h3>
              {
                cartItems.length === 0 ? (<p> Your cart is Empty !!</p>) : 
                (
                    <>
                    {
                        cartItems.map( item => (
                            <div key={item.id}>
                                <h3> {item.name}</h3>
                                <p> INR. {item.price} </p>
                                <button onClick={ () => dispatch(removeFromCart(item.id))}> Remove </button>
                            <hr/>
                            </div>
                        ))}

                        <button onClick={()=> dispatch(clearCart())}> Clear Cart</button>
                    </>
                )
              }
        </div>
    )
}

export default Cart;