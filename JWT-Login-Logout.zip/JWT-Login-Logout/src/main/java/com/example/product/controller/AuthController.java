package com.example.product.controller;

import java.util.HashSet;
import java.util.Set;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import com.example.product.service.JwtService;

@RestController
public class AuthController {
	
	private JwtService jwtService;
	
	private Set<String> loggedOutTokens = new HashSet<>();
	
	public AuthController(JwtService jwtService)
	{
		this.jwtService = jwtService;
	}
	
	@PostMapping("/login")
	public ResponseEntity<String> login(@RequestHeader String username, @RequestHeader String password ){
		
		if(username.equals("admin") && password.equals("admin123")) {
			
			String token = jwtService.generateToken(username);
			return ResponseEntity.ok(token);
		}
		return ResponseEntity.status(401).body("Invalid username or password");
	}
	
	@PostMapping("/logout")
	public ResponseEntity<String> logout(@RequestHeader("Authorization") String authorization)
	{
		String token = authorization.substring(7);
		loggedOutTokens.add(token);
		
		return ResponseEntity.ok("Logout successfull");
	}

}
