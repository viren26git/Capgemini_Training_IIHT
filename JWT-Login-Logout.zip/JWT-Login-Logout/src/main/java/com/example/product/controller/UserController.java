package com.example.product.controller;

import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
	
	@GetMapping("/user")
	public String user(Authentication authentication) {
		return "Welcome " + authentication.getName();
	}
}
