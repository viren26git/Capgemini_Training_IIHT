package com.example.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtLoginLogoutApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtLoginLogoutApplication.class, args);
	}

}
